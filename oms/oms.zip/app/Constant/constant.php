<?php
define('JOBSTATUS',array("pending", "on going"));
define('USERTYPE',array("Admin", "User"));
define('USERSTATUS',array("Active", "Deactive"));
