<div class="text-center">
    2018 &copy; Tekno Visual . | Designed & Developed by <a target="_blank" href="#">Tekno Visual.</a>
    <a href="#" class="go-top">
        <i class="fa fa-angle-up"></i>
    </a>
</div>
