<!-- js placed at the end of the document so the pages load faster -->
<script src="{{url('js/jquery.js')}}"></script>
{{--<script src="{{url('js/jquery-1.8.3.min.js')}}"></script>--}}
{{--<script src="https://code.jquery.com/jquery-1.10.2.js"></script>--}}
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--script for this page-->

<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js"></script>

<script src="{{url('js/bootstrap.min.js')}}"></script>
<script class="include" type="text/javascript" src="{{url('js/jquery.dcjqaccordion.2.7.js')}}"></script>
<script src="{{url('js/jquery.scrollTo.min.js')}}"></script>

<script src="https://use.fontawesome.com/45e03a14ce.js"></script>
<!--common script for all pages-->
<script src="{{url('js/common-scripts.js')}}"></script>

