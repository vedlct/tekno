<link rel="shortcut icon" href="{{url('img/TCL_logo.png')}}">

<title>OMS - Order Management System.</title>

<!-- Bootstrap core CSS -->
<link href="{{url('css/bootstrap.min.css')}}" rel="stylesheet">
{{--<link href="{{url('css/bootstrap-reset.css')}}" rel="stylesheet">--}}
<!--external css-->
<link href="{{url('assets/font-awesome/css/font-awesome.css')}}" rel="stylesheet" />
<link href="{{url('assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css')}}" rel="stylesheet" type="text/css" media="screen"/>
<link rel="stylesheet" href="{{url('css/owl.carousel.css')}}" type="text/css">
<!-- Custom styles for this template -->
<link href="{{url('css/style.css')}}" rel="stylesheet">
<link href="{{url('css/style-responsive.css')}}" rel="stylesheet" />


<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.css" rel="stylesheet">

<link href="{{url('css/chat.css')}}" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<link href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css" >


<!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
<!--[if lt IE 9]>
<script src="{{url('js/html5shiv.js')}}"></script>
<script src="{{url('js/respond.min.js')}}"></script>




<![endif]-->