@extends('main')



@section('content')


        <!--<div class="banner_area">
            <img src="images/about.png" alt="">
        </div>-->

        <div class="contact_title">
            <h2>About Us</h2> <hr>
        </div>

        <div class="container">

            <div style="padding-top:30px">
                <p style="text-align:justify">Here at Tekno Visual we strive to provide our clients partners with the best
                    digital development experience. Whether it may be as simple as basic
                    graphic artwork or something more complex as custom software for business,
                    our job is to insure your job is as stress free as possible. We thrive
                    off eliminating that stressful environment the that technology aspect of
                    your business may create for you. We are your development hub for all your
                    digital content needs. To get started,One of our highly trained & experience
                    business analysts will provide free consultation in order to analyze, locate
                    and eliminate your business stress points.</p>
            </div>

            <div style="padding-top:30px">
                <div class="vision_title">
                    <h2>Our vission</h2><hr>
                </div>
                <div class="vision_content">
                    <p style="text-align:justify">Our vision is to provide the peace of mind to our business partners when it
                        comes to building an online presence, design & development of all digital
                        content and automating of business process with the right technologies in
                        place.</p>
                </div>
            </div>

        </div>





        <section class="grid">





        </section>




@endsection